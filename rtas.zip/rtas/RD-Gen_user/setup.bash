#!/bin/bash

sudo apt update
sudo apt upgrade
sudo apt install graphviz graphviz-dev
pip3 install -r ./requirements.txt
