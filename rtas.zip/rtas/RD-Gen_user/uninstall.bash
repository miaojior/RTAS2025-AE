#!/bin/bash

sudo apt remove graphviz graphviz-dev
pip3 uninstall -y -r ./requirements.txt
